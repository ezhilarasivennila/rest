package com.example.helloworldrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.example")
public class HelloworldRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloworldRestApplication.class, args);
	}

}
