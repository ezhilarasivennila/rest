package com.example.helloworldrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloworldRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
